/* in hello.c */
#include <stdio.h>
#include <stdlib.h>

int main() {
  char arr[4];

  unsigned int zo = 4294967295;
  arr[0] = zo & 0xFF;
  arr[1] = (zo >> 8) & 0xFF;
  arr[2] = (zo >> 16) & 0xFF;
  arr[3] = (zo >> 24) & 0xFF;

  printf("0x%02x 0x%02x 0x%02x 0x%02x\n", (u_int8_t) arr[3], (u_int8_t) arr[2], (u_int8_t) arr[1], (u_int8_t) arr[0]);

  u_int32_t odo = (arr[3] << 24) | (arr[2] << 16) | (arr[1] << 0) | arr[0];
  char buf[256];
  printf("%u\n", odo);
  exit(0);
}

