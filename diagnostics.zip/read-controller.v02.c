#define TERMINAL    "/dev/ttyUSB0"

#include <errno.h>
#include <fcntl.h> 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <termios.h>
#include <unistd.h>
#define FRAME_SIZE 14

#define INTERVAL_IN_MS 100

float odometer = 0;

int set_interface_attribs(int fd, int speed)
{
  struct termios tty;

  if (tcgetattr(fd, &tty) < 0) {
    printf("Error from tcgetattr: %s\n", strerror(errno));
    return -1;
  }

  cfsetospeed(&tty, (speed_t)speed);
  cfsetispeed(&tty, (speed_t)speed);

  tty.c_cflag |= (CLOCAL | CREAD);    /* ignore modem controls */
  tty.c_cflag &= ~CSIZE;
  tty.c_cflag |= CS8;         /* 8-bit characters */
  tty.c_cflag &= ~PARENB;     /* no parity bit */
  tty.c_cflag &= ~CSTOPB;     /* only need 1 stop bit */
  tty.c_cflag &= ~CRTSCTS;    /* no hardware flowcontrol */

  /* setup for non-canonical mode */
  tty.c_iflag &= ~(IGNBRK | BRKINT | PARMRK | ISTRIP | INLCR | IGNCR | ICRNL | IXON);
  tty.c_lflag &= ~(ECHO | ECHONL | ICANON | ISIG | IEXTEN);
  tty.c_oflag &= ~OPOST;

  /* fetch bytes as they become available */
  tty.c_cc[VMIN] = 1;
  tty.c_cc[VTIME] = 1;

  if (tcsetattr(fd, TCSANOW, &tty) != 0) {
    printf("Error from tcsetattr: %s\n", strerror(errno));
    return -1;
  }
  return 0;
}

void print_buffer(unsigned char* frame_buf) {
  unsigned char   *p;
  for (p = frame_buf; p < frame_buf + FRAME_SIZE; p++)
    printf("0x%x ", *p);
  printf("\n");
}

#define PI 3.14159
float get_speed(unsigned char* frame_buf) {
  unsigned char   *p;
  unsigned int MSB = frame_buf[8];
  unsigned int LSB = frame_buf[9];
  // printf("0x%02x, 0x%02x\n", MSB, LSB);
  unsigned int wheel_diameter_mm = 241;
  unsigned int rotation_time_in_ms = (MSB << 8) + LSB;
  //printf("%d\n", rotation_time_in_ms);
  float wheel_circumference_mm = PI * wheel_diameter_mm;
  float rotations_per_second = 1000 / (float) rotation_time_in_ms;
  float speed_in_km_per_hour = rotations_per_second * wheel_circumference_mm * 60 * 60 / 1000 / 1000;
  float meters_per_second = rotations_per_second * wheel_circumference_mm  / 1000;
  // printf("rot time %f ms\n", rotations_per_second);
  //  printf("per second %f\n", rotations_per_second);
  // printf("speed, km/h %f\n", speed_in_km_per_hour);
  if (MSB == 0x17 && LSB == 0x70)
    meters_per_second = 0;
  return(meters_per_second);
}

int valid_checksum(unsigned char* frame_buf) {
  unsigned char xor = 0;
  unsigned char *p;
  unsigned char tmp;
  for (p = frame_buf; p < frame_buf + (FRAME_SIZE-1); p++) {
    tmp = *p;
    xor = xor ^ tmp;
  }
  return(xor == frame_buf[FRAME_SIZE-1]);
}


int main()
{
  char *portname = TERMINAL;
  int fd;
  int wlen;
  char *xstr = "Hello!\n";
  int xlen = strlen(xstr);

  fd = open(portname, O_RDWR | O_NOCTTY | O_SYNC);
  if (fd < 0) {
    printf("Error opening %s: %s\n", portname, strerror(errno));
    return -1;
  }
  set_interface_attribs(fd, B9600);
  wlen = write(fd, xstr, xlen);
  if (wlen != xlen) {
    printf("Error from write: %d, %d\n", wlen, errno);
  }
  tcdrain(fd);    /* delay for output */

  unsigned int trigger = 0;
  // 0x02  0x0e  0x01  0x40  0x80  0x00  0x00  0x01  0x01  0xf1  0x00  0x00  0xff  0xc3
  //                                                 MSB   LSB                     checksum
  unsigned char frame_buf[FRAME_SIZE];
  unsigned int  buf_cnt = 0;
  do {
    unsigned char buf[80];
    int rdlen;
    rdlen = read(fd, buf, sizeof(buf) - 1);
    if (rdlen > 0) {
      // printf("0x%02x\n", buf[0]);
      if (trigger == 0 && buf[0] == 0){
        trigger++;
        // printf("1\n");
      } else if (trigger == 1 && buf[0] == 255){
        trigger++;
        // printf("2\n");
      } else if (trigger == 2) {
        trigger++;
        // printf("3\n");
      } else if (trigger == 3) {
        // printf("buf_cnt %d 0x%x\n", buf_cnt, buf[0]);
        memcpy(frame_buf + buf_cnt, buf, rdlen);
        buf_cnt = buf_cnt + rdlen;
        if (buf_cnt == FRAME_SIZE) {
          if (!valid_checksum(frame_buf)) {
            printf("checksum fuckerd\n");
            trigger = 0;
          } else {
            print_buffer(frame_buf);
            float meters_per_second = get_speed(frame_buf);
            odometer = odometer + ( meters_per_second * ( (float) INTERVAL_IN_MS / 1000 ) );
            printf("%d km/h (%d m)\n", (int) (meters_per_second / 1000 * 60 * 60), (int) odometer);

         }
          buf_cnt = 0;
        }
      } else if (trigger == 4) {
        trigger = 0; // try again to align
        printf("broke\n");
      }
    } else if (rdlen < 0) {
      printf("Error from read: %d: %s\n", rdlen, strerror(errno));
    } else {  /* rdlen == 0 */
      printf("Timeout from read\n");
    }               
    /* repeat read to get full message */
  } while (1);
}
