#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <unistd.h>

double last_odometer = 0;
double current_odometer = 124;

void display_odometer(void) {
  if  ( (unsigned long) current_odometer == (unsigned long) last_odometer )
    return;

  double current_odometer_copy = current_odometer;
  double last_odometer_copy = last_odometer;
  
  unsigned int last_odometer_previous_msd = 0;
  unsigned int current_odometer_previous_msd = 0;
  unsigned int offset = 0;

  for (int idx = 7; idx >= 0; idx--){
    last_odometer_copy = last_odometer_copy - last_odometer_previous_msd;
    unsigned int last_odometer_sd = last_odometer_copy / pow(10, idx);
    last_odometer_previous_msd = last_odometer_sd * pow(10, idx);

    current_odometer_copy = current_odometer_copy - current_odometer_previous_msd;
    unsigned int current_odometer_sd = current_odometer_copy / pow(10, idx);
    current_odometer_previous_msd = current_odometer_sd * pow(10, idx);

    if (current_odometer_sd != last_odometer_sd ) {
      // erase old digit, write new digit
      printf("loop %d, current: %d, last: %d, offset: %d\n", idx, current_odometer_sd, last_odometer_sd, offset);
    }

    offset = offset + 10;
  }
}

int main() {
  display_odometer();
  printf("last   : %f\n", last_odometer);
  printf("current: %f\n", current_odometer);

}
